using MySql.Data.MySqlClient;
using System.ComponentModel;
using System.Configuration;

namespace salary.MVVM.Model
{
    public class Brigade : INotifyProperty