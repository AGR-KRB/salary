using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using salary.MVVM.Model;

namespace salary.MVVM.View
{
    public partial class HomeView : UserControl
    {
        private List<BrigadeEmployee> _employees; // List of employees for the current sheet

        public HomeView()
        {
            InitializeComponent();
            LoadEmployeeData();
        }

        private void LoadEmployeeData()
        {
            _employees = EmployeeRepository.LoadBrigadeEmployees(); // Load employee data (general)
            employeeDataGrid.ItemsSource = _employees;
        }

        private void SalaryDataGrid_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (salaryDataGrid.SelectedItem is Salary selectedSalary)
            {
                EditSalaryWindow editWindow = new EditSalaryWindow(selectedSalary);
                bool? result = editWindow.ShowDialog();

                if (result == true)
                {
                    // Refresh data in DataGrid after editing
                    salaryDataGrid.Items.Refresh();
                }
            }
        }
    }
}