using System.Windows;
using salary.MVVM.Model;

namespace salary.MVVM.View
{
    public partial class EditSalaryWindow : Window
    {
        private Salary _salary;

        public EditSalaryWindow(Salary salary)
        {
            InitializeComponent();
            _salary = salary;
            DataContext = _salary;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            _salary.CalculateSalary(); // Calculate and save data to the database
            _salary.SaveToDatabase();
            DialogResult = true; // Close the window with the result "True"
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false; // Close the window without changes
            Close();
        }
    }
}