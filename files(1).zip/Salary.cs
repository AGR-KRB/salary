using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.Configuration;

namespace salary.MVVM.Model
{
    public class Salary : INotifyPropertyChanged
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["mysqlConnection"].ConnectionString;

        public int SalaryID { get; set; }
        public string EmployeeID { get; set; }
        public string WorksiteID { get; set; }
        public int WorkHours { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal Bonus { get; set; }
        public decimal Deductions { get; set; }
        public decimal Alimony { get; set; }
        public decimal VacationPay { get; set; }
        public decimal SickPay { get; set; }
        public int OvertimeHours { get; set; }
        public decimal WeatherImpact { get; set; }
        public decimal TotalIncome { get; private set; }
        public decimal TotalDeductions { get; private set; }
        public decimal NetSalary { get; private set; }

        // Method to save salary data to the database
        public void SaveToDatabase()
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                var command = new MySqlCommand(@"
                    INSERT INTO Salaries (SalaryID, EmployeeID, WorksiteID, WorkHours, HourlyRate, Bonus, Deductions, Alimony, VacationPay, SickPay, OvertimeHours, WeatherImpact)
                    VALUES (@SalaryID, @EmployeeID, @WorksiteID, @WorkHours, @HourlyRate, @Bonus, @Deductions, @Alimony, @VacationPay, @SickPay, @OvertimeHours, @WeatherImpact)
                    ON DUPLICATE KEY UPDATE 
                        WorkHours = @WorkHours, 
                        HourlyRate = @HourlyRate, 
                        Bonus = @Bonus, 
                        Deductions = @Deductions, 
                        Alimony = @Alimony, 
                        VacationPay = @VacationPay, 
                        SickPay = @SickPay, 
                        OvertimeHours = @OvertimeHours, 
                        WeatherImpact = @WeatherImpact", connection);

                command.Parameters.AddWithValue("@SalaryID", SalaryID);
                command.Parameters.AddWithValue("@EmployeeID", EmployeeID);
                command.Parameters.AddWithValue("@WorksiteID", WorksiteID);
                command.Parameters.AddWithValue("@WorkHours", WorkHours);
                command.Parameters.AddWithValue("@HourlyRate", HourlyRate);
                command.Parameters.AddWithValue("@Bonus", Bonus);
                command.Parameters.AddWithValue("@Deductions", Deductions);
                command.Parameters.AddWithValue("@Alimony", Alimony);
                command.Parameters.AddWithValue("@VacationPay", VacationPay);
                command.Parameters.AddWithValue("@SickPay", SickPay);
                command.Parameters.AddWithValue("@OvertimeHours", OvertimeHours);
                command.Parameters.AddWithValue("@WeatherImpact", WeatherImpact);

                command.ExecuteNonQuery();
            }
        }

        // Method to calculate salary
        public void CalculateSalary()
        {
            TotalIncome = (WorkHours * HourlyRate) + Bonus + SickPay + (OvertimeHours * (HourlyRate * 1.5m));
            TotalDeductions = Deductions + Alimony + WeatherImpact;
            NetSalary = TotalIncome - TotalDeductions;

            OnPropertyChanged(nameof(TotalIncome));
            OnPropertyChanged(nameof(TotalDeductions));
            OnPropertyChanged(nameof(NetSalary));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}