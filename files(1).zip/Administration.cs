using MySql.Data.MySqlClient;
using System.ComponentModel;
using System.Configuration;

namespace salary.MVVM.Model
{
    public class Administration : INotifyPropertyChanged
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["mysqlConnection"].ConnectionString;

        public string AdminID { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public int WorkHours { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal Bonus { get; set; }

        public void SaveToDatabase()
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                var command = new MySqlCommand(@"
                    INSERT INTO Administration (AdminID, Name, Position, WorkHours, HourlyRate, Bonus)
                    VALUES (@AdminID, @Name, @Position, @WorkHours, @HourlyRate, @Bonus)
                    ON DUPLICATE KEY UPDATE 
                        Name = @Name, 
                        Position = @Position, 
                        WorkHours = @WorkHours, 
                        HourlyRate = @HourlyRate, 
                        Bonus = @Bonus", connection);

                command.Parameters.AddWithValue("@AdminID", AdminID);
                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Position", Position);
                command.Parameters.AddWithValue("@WorkHours", WorkHours);
                command.Parameters.AddWithValue("@HourlyRate", HourlyRate);
                command.Parameters.AddWithValue("@Bonus", Bonus);

                command.ExecuteNonQuery();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}