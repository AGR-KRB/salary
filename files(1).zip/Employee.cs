using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.Configuration;

namespace salary.MVVM.Model
{
    public class Employee : INotifyPropertyChanged
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["mysqlConnection"].ConnectionString;

        public string EmployeeID { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public int WorkHours { get; set; }
        public decimal HourlyRate { get; set; }
        public decimal Bonus { get; set; }
        public decimal Deductions { get; set; }
        public decimal Alimony { get; set; }
        public decimal VacationPay { get; set; }
        public decimal SickPay { get; set; }

        public decimal TotalIncome => (WorkHours * HourlyRate) + Bonus + SickPay;
        public decimal TotalDeductions => Deductions + (TotalIncome * 0.34m) + (TotalIncome * 0.01m) + (TotalIncome * 0.006m);
        public decimal NetSalary => TotalIncome - TotalDeductions;

        // Method to recalculate and save data
        public void Recalculate()
        {
            OnPropertyChanged(nameof(TotalIncome));
            OnPropertyChanged(nameof(TotalDeductions));
            OnPropertyChanged(nameof(NetSalary));

            SaveToDatabase(); // Save changes to the database
        }

        // Method to save employee data to the database
        private void SaveToDatabase()
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                var command = new MySqlCommand(@"
                    UPDATE Employees SET 
                        Name = @Name, 
                        Position = @Position, 
                        WorkHours = @WorkHours, 
                        HourlyRate = @HourlyRate, 
                        Bonus = @Bonus, 
                        Deductions = @Deductions, 
                        Alimony = @Alimony, 
                        VacationPay = @VacationPay, 
                        SickPay = @SickPay, 
                        TotalIncome = @TotalIncome, 
                        TotalDeductions = @TotalDeductions, 
                        NetSalary = @NetSalary 
                    WHERE EmployeeID = @EmployeeID", connection);

                command.Parameters.AddWithValue("@EmployeeID", EmployeeID);
                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Position", Position);
                command.Parameters.AddWithValue("@WorkHours", WorkHours);
                command.Parameters.AddWithValue("@HourlyRate", HourlyRate);
                command.Parameters.AddWithValue("@Bonus", Bonus);
                command.Parameters.AddWithValue("@Deductions", Deductions);
                command.Parameters.AddWithValue("@Alimony", Alimony);
                command.Parameters.AddWithValue("@VacationPay", VacationPay);
                command.Parameters.AddWithValue("@SickPay", SickPay);
                command.Parameters.AddWithValue("@TotalIncome", TotalIncome);
                command.Parameters.AddWithValue("@TotalDeductions", TotalDeductions);
                command.Parameters.AddWithValue("@NetSalary", NetSalary);

                command.ExecuteNonQuery();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}