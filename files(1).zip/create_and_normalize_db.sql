-- Create database
CREATE DATABASE IF NOT EXISTS salary_db;
USE salary_db;

-- Create Employees table
CREATE TABLE IF NOT EXISTS Employees (
    EmployeeID VARCHAR(255) PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Position VARCHAR(255) NOT NULL,
    WorkHours INT NOT NULL,
    HourlyRate DECIMAL(10, 2) NOT NULL,
    Bonus DECIMAL(10, 2) NOT NULL,
    Deductions DECIMAL(10, 2) NOT NULL,
    Alimony DECIMAL(10, 2) NOT NULL,
    VacationPay DECIMAL(10, 2) NOT NULL,
    SickPay DECIMAL(10, 2) NOT NULL,
    TotalIncome DECIMAL(10, 2) GENERATED ALWAYS AS ((WorkHours * HourlyRate) + Bonus + SickPay) STORED,
    TotalDeductions DECIMAL(10, 2) GENERATED ALWAYS AS (Deductions + (TotalIncome * 0.34) + (TotalIncome * 0.01) + (TotalIncome * 0.006)) STORED,
    NetSalary DECIMAL(10, 2) GENERATED ALWAYS AS (TotalIncome - TotalDeductions) STORED
);

-- Create Users table
CREATE TABLE IF NOT EXISTS Users (
    Username VARCHAR(255) PRIMARY KEY,
    Password VARCHAR(255) NOT NULL,
    Name VARCHAR(255) NOT NULL
);

-- Insert sample data into Employees table
INSERT INTO Employees (EmployeeID, Name, Position, WorkHours, HourlyRate, Bonus, Deductions, Alimony, VacationPay, SickPay)
VALUES
('E001', 'John Doe', 'Developer', 160, 50.00, 500.00, 100.00, 50.00, 200.00, 100.00),
('E002', 'Jane Smith', 'Manager', 160, 60.00, 600.00, 200.00, 100.00, 150.00, 200.00);

-- Insert sample data into Users table
INSERT INTO Users (Username, Password, Name)
VALUES
('jdoe', 'password123', 'John Doe'),
('jsmith', 'password456', 'Jane Smith');