using salary.MVVM.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace salary.MVVM.View
{
    public partial class WorkersView : UserControl
    {
        private List<BrigadeEmployee> employees = new List<BrigadeEmployee>();

        public WorkersView()
        {
            InitializeComponent(); // Binds XAML and code
        }

        private void ClearFields()
        {
            txtEmployeeID.Clear();
            txtName.Clear();
            txtPosition.Clear();
            txtWorkHours.Clear();
            txtHourlyRate.Clear();
            txtBonus.Clear();
        }

        private void TextBox_OnlyNumbers_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text, @"^\d+(,\d{0,2})?$");
        }

        private void TextBox_OnlyNumbers_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }

        private bool IsTextAllowed(string text, string pattern)
        {
            return Regex.IsMatch(text, pattern);
        }

        private void AddEmployee_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Get the entered data
                BrigadeEmployee newEmployee = new BrigadeEmployee
                {
                    EmployeeID = txtEmployeeID.Text, // Tab number
                    Name =