using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace salary.MVVM.Model
{
    public static class EmployeeRepository
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["mysqlConnection"].ConnectionString;

        public static void SaveEmployees(List<Employee> employees)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                foreach (var employee in employees)
                {
                    var command = new MySqlCommand(@"
                        INSERT INTO Employees (EmployeeID, Name, Position, WorkHours, HourlyRate, Bonus, Deductions, Alimony, VacationPay, SickPay) 
                        VALUES (@EmployeeID, @Name, @Position, @WorkHours, @HourlyRate, @Bonus, @Deductions, @Alimony, @VacationPay, @SickPay)
                        ON DUPLICATE KEY UPDATE 
                        Name = @Name, 
                        Position = @Position, 
                        WorkHours = @WorkHours, 
                        HourlyRate = @HourlyRate, 
                        Bonus = @Bonus, 
                        Deductions = @Deductions, 
                        Alimony = @Alimony, 
                        VacationPay = @VacationPay, 
                        SickPay = @SickPay", connection);

                    command.Parameters.AddWithValue("@EmployeeID", employee.EmployeeID);
                    command.Parameters.AddWithValue("@Name", employee.Name);
                    command.Parameters.AddWithValue("@Position", employee.Position);
                    command.Parameters.AddWithValue("@WorkHours", employee.WorkHours);
                    command.Parameters.AddWithValue("@HourlyRate", employee.HourlyRate);
                    command.Parameters.AddWithValue("@Bonus", employee.Bonus);
                    command.Parameters.AddWithValue("@Deductions", employee.Deductions);
                    command.Parameters.AddWithValue("@Alimony", employee.Alimony);
                    command.Parameters.AddWithValue("@VacationPay", employee.VacationPay);
                    command.Parameters.AddWithValue("@SickPay", employee.SickPay);

                    command.ExecuteNonQuery();
                }
            }
        }

        public static List<Employee> LoadEmployees()
        {
            var employees = new List<Employee>();

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                var command = new MySqlCommand("SELECT * FROM Employees", connection);
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        employees.Add(new Employee
                        {
                            EmployeeID = reader["EmployeeID"].ToString(),
                            Name = reader["Name"].ToString(),
                            Position = reader["Position"].ToString(),
                            WorkHours = int.Parse(reader["WorkHours"].ToString()),
                            HourlyRate = decimal.Parse(reader["HourlyRate"].ToString()),
                            Bonus = decimal.Parse(reader["Bonus"].ToString()),
                            Deductions = decimal.Parse(reader["Deductions"].ToString()),
                            Alimony = decimal.Parse(reader["Alimony"].ToString()),
                            VacationPay = decimal.Parse(reader["VacationPay"].ToString()),
                            SickPay = decimal.Parse(reader["SickPay"].ToString())
                        });
                    }
                }
            }

            return employees;
        }
    }
}