using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Configuration;

namespace salary.MVVM.Model
{
    public class Worksite : INotifyPropertyChanged
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["mysqlConnection"].ConnectionString;

        public string WorksiteID { get; set; }
        public string Location { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string BrigadeID { get; set; }
        public string Status { get; set; }

        // Method to save worksite data to the database
        public void SaveToDatabase()
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                var command = new MySqlCommand(@"
                    INSERT INTO Worksites (WorksiteID, Location, StartDate, EndDate, BrigadeID, Status)
                    VALUES (@WorksiteID, @Location, @StartDate, @EndDate, @BrigadeID, @Status)
                    ON DUPLICATE KEY UPDATE 
                        Location = @Location, 
                        StartDate = @StartDate, 
                        EndDate = @EndDate, 
                        BrigadeID = @BrigadeID, 
                        Status = @Status", connection);

                command.Parameters.AddWithValue("@WorksiteID", WorksiteID);
                command.Parameters.AddWithValue("@Location", Location);
                command.Parameters.AddWithValue("@StartDate", StartDate);
                command.Parameters.AddWithValue("@EndDate", EndDate);
                command.Parameters.AddWithValue("@BrigadeID", BrigadeID);
                command.Parameters.AddWithValue("@Status", Status);

                command.ExecuteNonQuery();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}