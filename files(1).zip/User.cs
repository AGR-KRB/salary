using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.Configuration;

namespace salary.MVVM.Model
{
    public class User : INotifyPropertyChanged
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["mysqlConnection"].ConnectionString;

        public string Username { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }

        // Method to save user data to the database
        public void SaveToDatabase()
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                var command = new MySqlCommand(@"
                    INSERT INTO Users (Username, Password, Name, Role)
                    VALUES (@Username, @Password, @Name, @Role)
                    ON DUPLICATE KEY UPDATE 
                        Password = @Password, 
                        Name = @Name, 
                        Role = @Role", connection);

                command.Parameters.AddWithValue("@Username", Username);
                command.Parameters.AddWithValue("@Password", Password);
                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Role", Role);

                command.ExecuteNonQuery();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}