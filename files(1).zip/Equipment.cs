using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.Configuration;

namespace salary.MVVM.Model
{
    public class Equipment : INotifyPropertyChanged
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["mysqlConnection"].ConnectionString;

        public string EquipmentID { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public decimal DailyRent { get; set; }
        public string BrigadeID { get; set; }
        public string WorksiteID { get; set; }

        // Method to save equipment data to the database
        public void SaveToDatabase()
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                var command = new MySqlCommand(@"
                    INSERT INTO Equipment (EquipmentID, Name, Type, DailyRent, BrigadeID, WorksiteID)
                    VALUES (@EquipmentID, @Name, @Type, @DailyRent, @BrigadeID, @WorksiteID)
                    ON DUPLICATE KEY UPDATE 
                        Name = @Name, 
                        Type = @Type, 
                        DailyRent = @DailyRent, 
                        BrigadeID = @BrigadeID, 
                        WorksiteID = @WorksiteID", connection);

                command.Parameters.AddWithValue("@EquipmentID", EquipmentID);
                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Type", Type);
                command.Parameters.AddWithValue("@DailyRent", DailyRent);
                command.Parameters.AddWithValue("@BrigadeID", BrigadeID);
                command.Parameters.AddWithValue("@WorksiteID", WorksiteID);

                command.ExecuteNonQuery();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}